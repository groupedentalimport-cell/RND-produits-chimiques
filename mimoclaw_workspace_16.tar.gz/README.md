# ⚗️ ChemStab Industrial v5.1 — StabilityLab

**Professional chemical stability assessment platform with QSPR/ML predictions, multi-tenant architecture, GxP audit trail, and ICH/FDA/EMA regulatory reports.**

---

## What's New in v5.1 (Industrial Upgrade)

| Feature | v5 (Previous) | v5.1 (Industrial) |
|---|---|---|
| **Chemical Database** | 16 hardcoded compounds | PostgreSQL + ChEMBL/PubChem (100K+ capable) |
| **Molecular Descriptors** | Manual properties | RDKit 200+ descriptors + Morgan fingerprints |
| **ML/QSPR** | Rule-based on simulated data | scikit-learn QSPR with cross-validation |
| **Multi-tenancy** | Single-user | Organization → User RBAC (5 roles) |
| **Audit Trail** | In-memory | 21 CFR Part 11 compliant, DB-backed, immutable |
| **Reports** | Basic PDF/DOCX/XLSX | ICH Q1A(R2) compliant with electronic signatures |
| **Architecture** | SQLite + single process | PostgreSQL + Redis + Celery async |
| **Auth** | Basic JWT | JWT + MFA ready + password policy + account lockout |
| **API** | 8 endpoints | 25+ endpoints with OpenAPI docs |

---

## Architecture

```
chemstab-industrial/
├── backend/                     # Python FastAPI
│   ├── app/
│   │   ├── api/                 # REST endpoints
│   │   │   ├── auth.py          # JWT auth + GxP login tracking
│   │   │   ├── analysis.py      # Stability analysis + QSPR
│   │   │   ├── molecules.py     # Chemical database CRUD
│   │   │   ├── reports.py       # ICH/FDA report generation
│   │   │   └── admin.py         # System admin + ML training
│   │   ├── core/
│   │   │   ├── config.py        # Pydantic settings
│   │   │   ├── database.py      # SQLAlchemy + PostgreSQL
│   │   │   └── security.py      # JWT, bcrypt, RBAC, e-signatures
│   │   ├── engines/
│   │   │   ├── risk_engine.py   # 9 risk types (rule-based)
│   │   │   ├── kinetics.py      # Arrhenius, Q10, Van't Hoff
│   │   │   └── descriptors.py   # RDKit 200+ molecular descriptors
│   │   ├── ml/
│   │   │   └── qspr_engine.py   # QSPR pipeline (train, predict, save)
│   │   ├── models/              # SQLAlchemy ORM models
│   │   │   ├── organization.py  # Multi-tenant root
│   │   │   ├── user.py          # RBAC + GxP login tracking
│   │   │   ├── molecule.py      # Chemical entities + descriptors
│   │   │   ├── project.py       # Projects + analyses + shelf life
│   │   │   └── audit.py         # 21 CFR Part 11 audit trail
│   │   ├── services/
│   │   │   ├── chembl_loader.py # ChEMBL API integration
│   │   │   ├── gxp_audit.py     # GxP audit service
│   │   │   └── regulatory_reports.py  # ICH/FDA/EMA reports
│   │   └── main.py              # FastAPI app
│   ├── tests/
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/                    # React + TypeScript + Tailwind
│   └── src/
│       └── App.tsx              # Dashboard, Molecule Browser, Analysis
├── docker-compose.yml           # Full stack deployment
├── scripts/init.sql             # PostgreSQL init
└── docs/                        # Technical documentation
```

---

## Quick Start

### Option A: Docker Compose (Recommended)

```bash
# Clone and start
cd chemstab-industrial
docker compose up -d

# Access
# Frontend: http://localhost:3000
# Backend:  http://localhost:8000
# API Docs: http://localhost:8000/docs
# Default:  admin / Admin@ChemStab1!
```

### Option B: Local Development

```bash
# Backend
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000

# Frontend
cd frontend
npm install
npm run dev
```

---

## API Endpoints

### Authentication
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/auth/login` | Login (OAuth2 form) |
| POST | `/api/v1/auth/register` | Register user + org |
| POST | `/api/v1/auth/refresh` | Refresh token |
| POST | `/api/v1/auth/change-password` | Change password |
| GET | `/api/v1/auth/me` | Current user profile |

### Molecules
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/v1/molecules` | List molecules |
| GET | `/api/v1/molecules/{id}` | Get molecule + descriptors |
| POST | `/api/v1/molecules` | Create molecule (auto-descriptors) |
| POST | `/api/v1/molecules/search` | Search by name/SMILES/CAS |
| POST | `/api/v1/molecules/compute-descriptors` | Compute RDKit descriptors |
| POST | `/api/v1/molecules/import/chembl` | Import from ChEMBL |
| GET | `/api/v1/molecules/stats/database` | Database statistics |

### Analysis
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/analysis/run` | Run full stability analysis |
| POST | `/api/v1/analysis/kinetics/simulate` | Kinetic simulation |
| POST | `/api/v1/analysis/sign` | Electronic signature (21 CFR 11) |
| GET | `/api/v1/analysis/project/{id}` | List project analyses |

### Reports
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/reports/generate` | Generate PDF/DOCX/XLSX report |

### Admin
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/admin/train-qspr` | Train QSPR models |
| POST | `/api/v1/admin/molecules/batch-import` | Batch import from ChEMBL |
| GET | `/api/v1/admin/system/health` | System health check |

---

## QSPR/ML Pipeline

### Training
```python
# Via API
POST /api/v1/admin/train-qspr

# Via Python
from app.ml.qspr_engine import QSPRPipeline
pipeline = QSPRPipeline()
pipeline.train(X, y, "stability_score", descriptor_names)
pipeline.save()
```

### Molecular Descriptors (200+)
- **Constitutional**: MolWt, HeavyAtomCount, NumHDonors, NumHAcceptors...
- **Topological**: Chi indices, Kappa indices, BalabanJ, BertzCT...
- **Electronic**: EState, PEOE_VSA, BCUT2D...
- **Physical**: TPSA, MolLogP, MolMR...
- **Fingerprints**: Morgan/Circular (2048-bit)

### Prediction Confidence
Each prediction includes:
- **Confidence score** (0-1): Based on cross-validation R²
- **Applicability domain**: within_domain / extrapolation / out_of_domain
- **Uncertainty**: ± based on ensemble variance

---

## GxP Compliance (21 CFR Part 11)

### Audit Trail
Every action is logged:
- **Who**: Authenticated user ID (never "system")
- **What**: Action type + resource + details
- **When**: Immutable timestamp
- **Where**: IP address + user agent
- **Why**: Request context + session ID

### Electronic Signatures
- SHA-256 hash of record content
- Meaning of signature (e.g., "Reviewed and Approved")
- Timestamp + signer identity
- Immutable: no UPDATE/DELETE on signed records

### Password Policy
- Minimum 12 characters
- Upper + lower + digit + special character
- Account lockout after 5 failed attempts
- Configurable session timeout

---

## ICH/FDA Report Contents

1. Cover page with report metadata
2. Table of Contents
3. Executive Summary
4. Product Information
5. Test Substances (with CAS, concentrations, grades)
6. Analytical Methods & Conditions
7. Stability Risk Assessment (9 types)
8. Kinetic Analysis & Shelf Life Prediction
9. QSPR/ML Predictions with confidence
10. Packaging & Container Compatibility
11. Conclusions & Recommendations
12. Electronic Signatures
13. Audit Trail Reference

---

## Competitive Position

| Feature | ChemStab v5.1 | Schrödinger | StarDrop | Certara |
|---|---|---|---|---|
| **Price** | Open source | $$$$$ | $$$$ | $$$$ |
| **QSPR/ML** | ✅ | ✅ | ✅ | ✅ |
| **GxP Audit** | ✅ Built-in | Add-on | Add-on | ✅ |
| **Multi-tenant** | ✅ | ❌ | ❌ | ✅ |
| **Web-based** | ✅ | Desktop | Desktop | Desktop |
| **API-first** | ✅ | Limited | ❌ | Limited |
| **ICH Reports** | ✅ | Manual | Manual | ✅ |
| **ChEMBL Integration** | ✅ | Manual | Manual | Manual |

---

## Tech Stack

- **Backend**: Python 3.11, FastAPI, SQLAlchemy, Celery
- **Database**: PostgreSQL 16, Redis 7
- **ML**: scikit-learn, RDKit, NumPy, SciPy
- **Frontend**: React 18, TypeScript, Tailwind CSS, Recharts
- **Deployment**: Docker Compose, Nginx
- **Reports**: ReportLab (PDF), python-docx (DOCX), openpyxl (XLSX)

---

## License

Proprietary — All rights reserved.
