"""
ChemStab Industrial v5.1 — FastAPI Application
Professional chemical stability assessment with QSPR/ML, multi-tenant, GxP audit.
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import logging
import time

from app.core.config import settings
from app.core.database import init_db

# API routers
from app.api.auth import router as auth_router
from app.api.analysis import router as analysis_router
from app.api.molecules import router as molecules_router
from app.api.reports import router as reports_router
from app.api.admin import router as admin_router

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup/shutdown lifecycle."""
    logger.info(f"Starting {settings.APP_NAME} v{settings.APP_VERSION}")
    init_db()

    # Try to load QSPR models
    try:
        from app.ml.qspr_engine import qspr_pipeline
        if qspr_pipeline.load():
            logger.info("QSPR models loaded successfully")
        else:
            logger.info("No QSPR models found — train via /api/v1/admin/train-qspr")
    except Exception as e:
        logger.warning(f"QSPR model load skipped: {e}")

    yield
    logger.info("Shutting down")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description=(
        "Industrial-grade chemical stability assessment platform. "
        "QSPR predictions, multi-tenant, GxP audit trail, ICH/FDA/EMA reports."
    ),
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins_list,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    allow_headers=["Authorization", "Content-Type", "X-Request-ID"],
)


# Request timing middleware
@app.middleware("http")
async def add_timing_header(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    elapsed = time.time() - start
    response.headers["X-Response-Time"] = f"{elapsed:.3f}s"
    return response


# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "type": type(exc).__name__},
    )


# ── Register routers ───────────────────────────────────────────────────
app.include_router(auth_router, prefix="/api/v1")
app.include_router(analysis_router, prefix="/api/v1")
app.include_router(molecules_router, prefix="/api/v1")
app.include_router(reports_router, prefix="/api/v1")
app.include_router(admin_router, prefix="/api/v1")


# ── Root endpoints ─────────────────────────────────────────────────────

@app.get("/")
def root():
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "codename": settings.APP_CODENAME,
        "docs": "/docs",
        "status": "running",
        "features": [
            "QSPR molecular property prediction",
            "Multi-tenant with RBAC",
            "GxP audit trail (21 CFR Part 11)",
            "ICH/FDA/EMA regulatory reports",
            "ChEMBL/PubChem integration",
            "Kinetic degradation modeling",
        ],
    }


@app.get("/health")
def health():
    return {"status": "healthy", "version": settings.APP_VERSION}


@app.get("/version")
def version():
    return {
        "version": settings.APP_VERSION,
        "codename": settings.APP_CODENAME,
        "features": {
            "qspr_ml": True,
            "multi_tenant": True,
            "gxp_audit": True,
            "regulatory_reports": True,
            "chembl_integration": True,
        },
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
