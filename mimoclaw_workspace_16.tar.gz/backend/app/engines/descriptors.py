"""
Molecular Descriptor Engine — RDKit-based QSPR descriptors.
Computes 200+ molecular descriptors and Morgan fingerprints for ML.
"""

import numpy as np
from typing import Dict, Any, List, Optional, Tuple
import logging
import json

logger = logging.getLogger(__name__)

# Try to import RDKit — graceful degradation if not installed
try:
    from rdkit import Chem
    from rdkit.Chem import (
        Descriptors, Lipinski, rdMolDescriptors, rdFingerprintGenerator,
        AllChem, Draw, rdPartialCharges
    )
    from rdkit.Chem.MolStandardize import rdMolStandardize
    HAS_RDKIT = True
except ImportError:
    HAS_RDKIT = False
    logger.warning("RDKit not installed — molecular descriptor computation disabled")


# ── Descriptor names (200+) ───────────────────────────────────────────

DESCRIPTOR_NAMES = [
    # Constitutional
    "MolWt", "ExactMolWt", "HeavyAtomCount", "HeavyAtomMolWt",
    "NumHAcceptors", "NumHDonors", "NumHeteroatoms", "NumRotatableBonds",
    "NumValenceElectrons", "NumRadicalElectrons", "NumAliphaticCarbocycles",
    "NumAliphaticHeterocycles", "NumAliphaticRings", "NumAromaticCarbocycles",
    "NumAromaticHeterocycles", "NumAromaticRings", "NumSaturatedCarbocycles",
    "NumSaturatedHeterocycles", "NumSaturatedRings", "RingCount",
    "NumAmideBonds",

    # Topological
    "BalabanJ", "BertzCT", "Chi0", "Chi0n", "Chi0v", "Chi1", "Chi1n", "Chi1v",
    "Chi2n", "Chi2v", "Chi3n", "Chi3v", "Chi4n", "Chi4v",
    "HallKierAlpha", "Ipc", "Kappa1", "Kappa2", "Kappa3",
    "LabuteASA", "PEOE_VSA1", "PEOE_VSA2", "PEOE_VSA3", "PEOE_VSA4",
    "PEOE_VSA5", "PEOE_VSA6", "PEOE_VSA7", "PEOE_VSA8", "PEOE_VSA9",
    "PEOE_VSA10", "PEOE_VSA11", "PEOE_VSA12", "PEOE_VSA13", "PEOE_VSA14",
    "SMR_VSA1", "SMR_VSA2", "SMR_VSA3", "SMR_VSA4", "SMR_VSA5",
    "SMR_VSA6", "SMR_VSA7", "SMR_VSA8", "SMR_VSA9", "SMR_VSA10",
    "SlogP_VSA1", "SlogP_VSA2", "SlogP_VSA3", "SlogP_VSA4", "SlogP_VSA5",
    "SlogP_VSA6", "SlogP_VSA7", "SlogP_VSA8", "SlogP_VSA9", "SlogP_VSA10",
    "SlogP_VSA11", "EState_VSA1", "EState_VSA2", "EState_VSA3", "EState_VSA4",
    "EState_VSA5", "EState_VSA6", "EState_VSA7", "EState_VSA8", "EState_VSA9",
    "EState_VSA10", "EState_VSA11", "VSA_EState1", "VSA_EState2", "VSA_EState3",
    "VSA_EState4", "VSA_EState5", "VSA_EState6", "VSA_EState7", "VSA_EState8",
    "VSA_EState9", "VSA_EState10",

    # Electronic
    "MaxAbsEStateIndex", "MaxAbsPartialCharge", "MaxEStateIndex",
    "MaxPartialCharge", "MinAbsEStateIndex", "MinAbsPartialCharge",
    "MinEStateIndex", "MinPartialCharge",

    # Physical
    "TPSA", "MolLogP", "MolMR", "MolWt",

    # Drug-likeness
    "FractionCSP3", "NumAliphaticRings", "NumAromaticRings",
    "NumSaturatedRings", "NumHAcceptors", "NumHDonors",
    "NumRotatableBonds", "RingCount",

    # Autocorrelation
    "Autocorrelation2D_1", "Autocorrelation2D_2", "Autocorrelation2D_3",
    "Autocorrelation2D_4", "Autocorrelation2D_5",

    # BCUT
    "BCUT2D_MWHI", "BCUT2D_MWLOW", "BCUT2D_CHGHI", "BCUT2D_CHGLO",
    "BCUT2D_LOGPHI", "BCUT2D_LOGPLOW", "BCUT2D_MRHI", "BCUT2D_MRLOW",
]


def get_all_descriptor_functions():
    """Return dict of all available RDKit descriptor functions."""
    if not HAS_RDKIT:
        return {}
    return dict(Descriptors.descList)


def compute_descriptors(smiles: str) -> Dict[str, Any]:
    """
    Compute 200+ molecular descriptors from SMILES.
    Returns dict of descriptor_name → value.
    Returns empty dict if RDKit unavailable or SMILES invalid.
    """
    if not HAS_RDKIT:
        return {}

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        logger.warning(f"Invalid SMILES: {smiles}")
        return {}

    descriptors = {}
    desc_functions = get_all_descriptor_functions()

    for name, func in desc_functions.items():
        try:
            value = func(mol)
            if value is not None and np.isfinite(value):
                descriptors[name] = round(float(value), 6)
            else:
                descriptors[name] = 0.0
        except Exception:
            descriptors[name] = 0.0

    # Add custom descriptors
    try:
        descriptors["NumAmideBonds"] = rdMolDescriptors.CalcNumAmideBonds(mol)
        descriptors["NumBridgeheadAtoms"] = rdMolDescriptors.CalcNumBridgeheadAtoms(mol)
        descriptors["NumSpiroAtoms"] = rdMolDescriptors.CalcNumSpiroAtoms(mol)
        descriptors["NumAtomStereoCenters"] = len(Chem.FindMolChiralCenters(mol))
        descriptors["NumUnspecifiedAtomStereoCenters"] = len(
            Chem.FindMolChiralCenters(mol, includeUnassigned=True)
        )
    except Exception:
        pass

    return descriptors


def compute_fingerprint(smiles: str, radius: int = 2, n_bits: int = 2048) -> Optional[np.ndarray]:
    """
    Compute Morgan/Circular fingerprint as numpy array.
    Used for ML model input and similarity search.
    """
    if not HAS_RDKIT:
        return None

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None

    generator = rdFingerprintGenerator.GetMorganGenerator(radius=radius, fpSize=n_bits)
    fp = generator.GetFingerprintAsNumPy(mol)
    return fp


def compute_fingerprint_bits(smiles: str, radius: int = 2, n_bits: int = 2048) -> Optional[List[int]]:
    """Compute fingerprint as list of bit indices (for storage/DB)."""
    fp = compute_fingerprint(smiles, radius, n_bits)
    if fp is None:
        return None
    return fp.tolist()


def standardize_smiles(smiles: str) -> Optional[str]:
    """Canonicalize and standardize SMILES using RDKit."""
    if not HAS_RDKIT:
        return smiles

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None

    # Standardize
    normalizer = rdMolStandardize.Normalizer()
    mol = normalizer.normalize(mol)

    # Remove fragments (keep largest)
    chooser = rdMolStandardize.LargestFragmentChooser()
    mol = chooser.choose(mol)

    # Canonicalize
    return Chem.MolToSmiles(mol, canonical=True)


def compute_similarity(fp1: np.ndarray, fp2: np.ndarray) -> float:
    """Compute Tanimoto similarity between two fingerprints."""
    intersection = np.sum(fp1 & fp2)
    union = np.sum(fp1 | fp2)
    if union == 0:
        return 0.0
    return float(intersection / union)


def compute_molecular_formula(smiles: str) -> Optional[str]:
    """Get molecular formula from SMILES."""
    if not HAS_RDKIT:
        return None
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    return rdMolDescriptors.CalcMolFormula(mol)


def compute_lipinski_properties(smiles: str) -> Dict[str, Any]:
    """
    Compute Lipinski Rule of 5 properties.
    Returns dict with pass/fail and individual values.
    """
    if not HAS_RDKIT:
        return {}

    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {}

    mw = Descriptors.MolWt(mol)
    logp = Descriptors.MolLogP(mol)
    hbd = Descriptors.NumHDonors(mol)
    hba = Descriptors.NumHAcceptors(mol)
    psa = Descriptors.TPSA(mol)
    rotb = Descriptors.NumRotatableBonds(mol)

    violations = 0
    if mw > 500: violations += 1
    if logp > 5: violations += 1
    if hbd > 5: violations += 1
    if hba > 10: violations += 1

    return {
        "molecular_weight": round(mw, 2),
        "logp": round(logp, 2),
        "hbd": hbd,
        "hba": hba,
        "tpsa": round(psa, 2),
        "rotatable_bonds": rotb,
        "lipinski_violations": violations,
        "lipinski_pass": violations <= 1,
        "veber_pass": (rotb <= 10) and (psa <= 140),
        "drug_like": violations <= 1 and rotb <= 10 and psa <= 140,
    }


def batch_compute_descriptors(smiles_list: List[str]) -> List[Dict[str, Any]]:
    """Compute descriptors for a batch of SMILES strings."""
    results = []
    for smiles in smiles_list:
        desc = compute_descriptors(smiles)
        desc["_smiles"] = smiles
        results.append(desc)
    return results


def get_descriptor_vector(descriptors: Dict[str, float], descriptor_names: List[str]) -> np.ndarray:
    """Convert descriptor dict to fixed-length numpy vector for ML."""
    return np.array([descriptors.get(name, 0.0) for name in descriptor_names])
