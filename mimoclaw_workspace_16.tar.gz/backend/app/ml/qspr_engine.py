"""
QSPR Engine — Quantitative Structure-Property Relationship models.
Trains and predicts molecular properties from descriptors.
Validated with cross-validation, feature importance, applicability domain.
"""

import numpy as np
import json
import logging
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from pathlib import Path
import pickle

logger = logging.getLogger(__name__)

try:
    from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
    from sklearn.linear_model import ElasticNet, Ridge
    from sklearn.model_selection import cross_val_score, KFold
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
    from sklearn.feature_selection import VarianceThreshold, mutual_info_regression
    import joblib
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False
    logger.warning("scikit-learn not installed — QSPR models disabled")


@dataclass
class QSPRPrediction:
    """Single QSPR prediction result with confidence."""
    property_name: str
    predicted_value: float
    confidence: float  # 0-1
    applicability: str  # "within_domain", "extrapolation", "out_of_domain"
    model_version: str
    feature_importance: Dict[str, float] = field(default_factory=dict)
    uncertainty: float = 0.0  # ±


@dataclass
class QSPRModelMetrics:
    """Model performance metrics from cross-validation."""
    r2: float
    rmse: float
    mae: float
    cv_scores: List[float]
    n_samples: int
    n_features: int
    feature_importance: Dict[str, float]


class QSPRPipeline:
    """
    Full QSPR pipeline: feature selection → scaling → training → prediction.
    Supports multiple target properties.
    """

    TARGET_PROPERTIES = [
        "stability_score",
        "degradation_rate",
        "solubility_log",
        "oxidation_sensitivity",
        "hydrolysis_sensitivity",
        "melting_point",
        "logp",
    ]

    def __init__(self, models_dir: str = "./ml_models"):
        self.models_dir = Path(models_dir)
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.models: Dict[str, Any] = {}
        self.scalers: Dict[str, Any] = {}
        self.feature_selectors: Dict[str, Any] = {}
        self.descriptor_names: List[str] = []
        self.metadata: Dict[str, Any] = {}

    def select_features(
        self,
        X: np.ndarray,
        y: np.ndarray,
        feature_names: List[str],
        max_features: int = 50,
    ) -> Tuple[np.ndarray, List[str], np.ndarray]:
        """
        Feature selection: variance filter → mutual information → top-k.
        Returns (selected_X, selected_names, selector_mask).
        """
        # 1. Remove zero/low variance features
        var_selector = VarianceThreshold(threshold=0.01)
        X_var = var_selector.fit_transform(X)
        var_mask = var_selector.get_support()
        names_var = [f for f, m in zip(feature_names, var_mask) if m]

        # 2. Mutual information for regression
        mi_scores = mutual_info_regression(X_var, y, random_state=42)

        # 3. Select top-k features
        top_k = min(max_features, len(names_var))
        top_indices = np.argsort(mi_scores)[-top_k:]
        top_indices = np.sort(top_indices)

        X_selected = X_var[:, top_indices]
        selected_names = [names_var[i] for i in top_indices]
        importance = {names_var[i]: float(mi_scores[i]) for i in top_indices}

        return X_selected, selected_names, importance

    def train(
        self,
        X: np.ndarray,
        y: np.ndarray,
        property_name: str,
        feature_names: List[str],
        model_type: str = "gradient_boosting",
        cv_folds: int = 5,
    ) -> QSPRModelMetrics:
        """
        Train a QSPR model with cross-validation.
        Returns metrics and stores the trained model.
        """
        if not HAS_SKLEARN:
            raise RuntimeError("scikit-learn not installed")

        # Feature selection
        X_selected, selected_names, feature_importance = self.select_features(
            X, y, feature_names
        )

        # Scaling
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X_selected)

        # Model selection
        models = {
            "random_forest": RandomForestRegressor(
                n_estimators=200, max_depth=15, min_samples_split=5,
                min_samples_leaf=2, random_state=42, n_jobs=-1
            ),
            "gradient_boosting": GradientBoostingRegressor(
                n_estimators=200, max_depth=5, learning_rate=0.1,
                subsample=0.8, random_state=42
            ),
            "elastic_net": ElasticNet(alpha=0.01, l1_ratio=0.5, random_state=42, max_iter=5000),
            "ridge": Ridge(alpha=1.0),
        }

        model = models.get(model_type, models["gradient_boosting"])

        # Cross-validation
        kf = KFold(n_splits=cv_folds, shuffle=True, random_state=42)
        cv_scores = cross_val_score(model, X_scaled, y, cv=kf, scoring="r2")
        cv_rmse = np.sqrt(-cross_val_score(
            model, X_scaled, y, cv=kf, scoring="neg_mean_squared_error"
        ))

        # Train on full data
        model.fit(X_scaled, y)

        # Store
        self.models[property_name] = model
        self.scalers[property_name] = scaler
        self.feature_selectors[property_name] = {
            "names": selected_names,
            "importance": feature_importance,
        }

        # Metrics
        y_pred = model.predict(X_scaled)
        metrics = QSPRModelMetrics(
            r2=float(np.mean(cv_scores)),
            rmse=float(np.mean(cv_rmse)),
            mae=float(mean_absolute_error(y, y_pred)),
            cv_scores=cv_scores.tolist(),
            n_samples=len(y),
            n_features=len(selected_names),
            feature_importance=feature_importance,
        )

        self.metadata[property_name] = {
            "model_type": model_type,
            "cv_folds": cv_folds,
            "r2": metrics.r2,
            "rmse": metrics.rmse,
            "n_samples": metrics.n_samples,
            "n_features": metrics.n_features,
        }

        logger.info(f"Trained {property_name}: R²={metrics.r2:.3f}, RMSE={metrics.rmse:.3f}")
        return metrics

    def predict(
        self,
        X: np.ndarray,
        property_name: str,
        feature_names: Optional[List[str]] = None,
    ) -> QSPRPrediction:
        """
        Predict a property with confidence estimation.
        Confidence based on: model R², applicability domain, feature coverage.
        """
        if not HAS_SKLEARN:
            return QSPRPrediction(
                property_name=property_name,
                predicted_value=0.0,
                confidence=0.0,
                applicability="out_of_domain",
                model_version="none",
            )

        if property_name not in self.models:
            return QSPRPrediction(
                property_name=property_name,
                predicted_value=0.0,
                confidence=0.0,
                applicability="out_of_domain",
                model_version="no_model",
            )

        model = self.models[property_name]
        scaler = self.scalers[property_name]
        selector = self.feature_selectors[property_name]

        # Select and scale features
        selected_names = selector["names"]
        if feature_names:
            indices = [feature_names.index(n) for n in selected_names if n in feature_names]
            X_sel = X[:, indices] if len(X.shape) > 1 else X[indices].reshape(1, -1)
        else:
            X_sel = X

        X_scaled = scaler.transform(X_sel.reshape(1, -1) if len(X_sel.shape) == 1 else X_sel)

        # Predict
        prediction = float(model.predict(X_scaled)[0])

        # Confidence estimation
        meta = self.metadata.get(property_name, {})
        base_confidence = meta.get("r2", 0.5)

        # Check applicability domain (distance from training data centroid)
        applicability = "within_domain"
        if hasattr(model, "estimators_"):
            # For ensemble models, use prediction variance as uncertainty
            if hasattr(model, "estimators_"):
                individual_preds = np.array([est.predict(X_scaled)[0] for est in model.estimators_[:50]])
                uncertainty = float(np.std(individual_preds))
                # High variance = out of domain
                if uncertainty > meta.get("rmse", 1.0) * 2:
                    applicability = "extrapolation"
                    base_confidence *= 0.5
                elif uncertainty > meta.get("rmse", 1.0):
                    applicability = "extrapolation"
                    base_confidence *= 0.75
            else:
                uncertainty = 0.0
        else:
            uncertainty = meta.get("rmse", 0.0)

        return QSPRPrediction(
            property_name=property_name,
            predicted_value=round(prediction, 4),
            confidence=round(min(1.0, base_confidence), 3),
            applicability=applicability,
            model_version=f"{property_name}_v1",
            feature_importance=selector.get("importance", {}),
            uncertainty=round(uncertainty, 4),
        )

    def save(self, prefix: str = "qspr"):
        """Save all models, scalers, and metadata to disk."""
        for name, model in self.models.items():
            path = self.models_dir / f"{prefix}_{name}_model.joblib"
            joblib.dump(model, path)

        for name, scaler in self.scalers.items():
            path = self.models_dir / f"{prefix}_{name}_scaler.joblib"
            joblib.dump(scaler, path)

        # Save metadata and feature selectors
        meta_path = self.models_dir / f"{prefix}_metadata.json"
        with open(meta_path, "w") as f:
            json.dump({
                "metadata": self.metadata,
                "feature_selectors": {
                    k: {"names": v["names"], "importance": v["importance"]}
                    for k, v in self.feature_selectors.items()
                },
            }, f, indent=2)

        logger.info(f"Saved {len(self.models)} QSPR models to {self.models_dir}")

    def load(self, prefix: str = "qspr") -> bool:
        """Load models from disk. Returns True if successful."""
        try:
            meta_path = self.models_dir / f"{prefix}_metadata.json"
            if not meta_path.exists():
                return False

            with open(meta_path) as f:
                data = json.load(f)
            self.metadata = data.get("metadata", {})
            self.feature_selectors = data.get("feature_selectors", {})

            for name in self.metadata:
                model_path = self.models_dir / f"{prefix}_{name}_model.joblib"
                scaler_path = self.models_dir / f"{prefix}_{name}_scaler.joblib"

                if model_path.exists() and scaler_path.exists():
                    self.models[name] = joblib.load(model_path)
                    self.scalers[name] = joblib.load(scaler_path)

            logger.info(f"Loaded {len(self.models)} QSPR models")
            return len(self.models) > 0
        except Exception as e:
            logger.error(f"Failed to load QSPR models: {e}")
            return False

    def generate_training_data_from_chembl(
        self,
        molecules: List[Dict[str, Any]],
        descriptor_names: List[str],
    ) -> Tuple[np.ndarray, Dict[str, np.ndarray]]:
        """
        Generate training matrices from ChEMBL molecule data.
        Returns (X_descriptor_matrix, {property_name: y_values}).
        """
        X_rows = []
        y_dict = {prop: [] for prop in self.TARGET_PROPERTIES}

        for mol in molecules:
            descriptors = mol.get("descriptors", {})
            if not descriptors:
                continue

            # Build feature vector
            row = [descriptors.get(name, 0.0) for name in descriptor_names]
            X_rows.append(row)

            # Target values (from ChEMBL data or computed)
            for prop in self.TARGET_PROPERTIES:
                if prop == "stability_score":
                    # Compute from other properties
                    ox = mol.get("oxidation_sensitivity", 0)
                    hyd = mol.get("hydrolysis_sensitivity", 0)
                    light = mol.get("light_sensitivity", 0)
                    score = max(0, 100 - (ox * 30 + hyd * 25 + light * 20))
                    y_dict[prop].append(score)
                elif prop == "solubility_log":
                    sol = mol.get("solubility_water", 1.0)
                    y_dict[prop].append(np.log10(max(sol, 0.001)))
                else:
                    y_dict[prop].append(mol.get(prop, 0.0))

        X = np.array(X_rows) if X_rows else np.zeros((0, len(descriptor_names)))
        y_arrays = {k: np.array(v) for k, v in y_dict.items() if v}

        return X, y_arrays


# Global singleton
qspr_pipeline = QSPRPipeline()
